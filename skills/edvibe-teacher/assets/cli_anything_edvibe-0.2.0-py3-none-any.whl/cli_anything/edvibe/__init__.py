"""cli-anything-edvibe: CLI-Anything harness for edvibe.com."""
__version__ = "0.1.0"
