"""cli-anything-edvibe — Click CLI for edvibe.com materials.

One-shot subcommands plus a REPL when invoked without a subcommand; --json for
machine-readable output. Credentials: --email/--password or EDVIBE_EMAIL /
EDVIBE_PASSWORD env vars, or run `login` for an interactive first-time setup
(password never stored; session token cached in ~/.edvibe/session.json).
"""
import getpass
import json
import os
import shlex
import sys

import click

from .core.client import SESSION_DEFAULT, EdvibeError, EdvibeSession

CONTEXT_SETTINGS = {"help_option_names": ["-h", "--help"]}


def _creds(ctx):
    cfg = ctx.obj or {}
    email = cfg.get("email") or os.environ.get("EDVIBE_EMAIL")
    password = cfg.get("password") or os.environ.get("EDVIBE_PASSWORD")
    return email, password


def get_session(ctx, login=True):
    cfg = ctx.obj or {}
    email, password = _creds(ctx)
    sess = EdvibeSession(email=email, password=password,
                         session_path=cfg.get("session"))
    if login:
        sess.authenticate()
    return sess


def emit(ctx, data, human=None):
    if (ctx.obj or {}).get("json"):
        click.echo(json.dumps(data, ensure_ascii=False, indent=1))
    else:
        click.echo(human(data) if human else json.dumps(data, ensure_ascii=False))


# ---------------------------------------------------------------------- CLI
@click.group(invoke_without_command=True, context_settings=CONTEXT_SETTINGS)
@click.option("--email", envvar="EDVIBE_EMAIL", help="Edvibe login email")
@click.option("--password", envvar="EDVIBE_PASSWORD", help="Edvibe password")
@click.option("--session", default=None, help="Session cache path (default ~/.edvibe/session.json)")
@click.option("--json", "as_json", is_flag=True, help="Machine-readable JSON output")
@click.pass_context
def cli(ctx, email, password, session, as_json):
    """CLI-Anything harness for edvibe.com (materials & lessons)."""
    ctx.ensure_object(dict)
    ctx.obj["email"] = email
    ctx.obj["password"] = password
    ctx.obj["session"] = session
    ctx.obj["json"] = as_json
    if ctx.invoked_subcommand is None:
        ctx.invoke(repl)


# ---------------------------------------------------------------- status
@cli.command("whoami")
@click.pass_context
def whoami(ctx):
    """Show the authenticated Edvibe user."""
    sess = get_session(ctx)
    u = sess.user or sess.get_current_user()
    emit(ctx, {"id": u.get("Id"), "name": u.get("FullName"), "email": u.get("Email"),
               "school_id": u.get("SchoolId"), "role": u.get("Role")},
         human=lambda d: f"{d['name']} <{d['email']}> id={d['id']} school={d['school_id']} role={d['role']}")


@cli.command("logout")
@click.pass_context
def logout(ctx):
    """Forget the cached session token."""
    sess = get_session(ctx, login=False)
    sess.logout()
    emit(ctx, {"ok": True}, human=lambda d: "Logged out.")


@cli.command("login")
@click.option("--check", "check_only", is_flag=True, help="Just verify the cached session")
@click.pass_context
def login(ctx, check_only):
    """Log in to Edvibe and cache the session. Run this YOURSELF in your own
    terminal: the password is never stored and never shown to an agent."""
    sess = get_session(ctx, login=False)
    email, password = _creds(ctx)
    if check_only:
        try:
            u = sess.authenticate()
        except EdvibeError as exc:
            emit(ctx, {"ok": False, "error": str(exc)},
                 human=lambda d: f"NOT logged in: {d['error']}")
            raise SystemExit(1)
        emit(ctx, {"ok": True, "id": u.get("Id"), "name": u.get("FullName")},
             human=lambda d: f"Session OK: {d['name']} (id {d['id']})")
        return
    if not (email or password):
        try:
            u = sess.authenticate()
            emit(ctx, {"ok": True, "already": True, "name": u.get("FullName")},
                 human=lambda d: f"Already logged in as {d['name']}. "
                                 f"Run `logout` first to switch accounts.")
            return
        except EdvibeError:
            pass
    else:
        sess.logout()  # explicit creds: force a fresh login
    if not email:
        email = click.prompt("Edvibe email")
    if not password:
        password = getpass.getpass("Edvibe password (hidden, not stored): ")
    sess.email, sess.password = email.strip(), password
    try:
        u = sess.authenticate()
    except EdvibeError as exc:
        emit(ctx, {"ok": False, "error": str(exc)},
             human=lambda d: f"Login failed: {d['error']}")
        raise SystemExit(1)
    emit(ctx, {"ok": True, "id": u.get("Id"), "name": u.get("FullName")},
         human=lambda d: f"Logged in as {d['name']} (id {d['id']}). "
                         f"Session cached in {SESSION_DEFAULT}.")


@cli.command("doctor")
@click.pass_context
def doctor(ctx):
    """Check the local setup: python, dependencies, session, live connection."""
    checks = []

    def add(name, ok, detail=""):
        checks.append({"check": name, "ok": bool(ok), "detail": str(detail)})

    add("python", sys.version_info >= (3, 9), sys.version.split()[0])
    for mod in ("requests", "websocket", "click"):
        try:
            __import__(mod)
            add(f"dep:{mod}", True, "ok")
        except Exception as exc:
            add(f"dep:{mod}", False, str(exc))
    path = (ctx.obj or {}).get("session") or SESSION_DEFAULT
    add("session-file", os.path.exists(path), path)
    sess = get_session(ctx, login=False)
    try:
        u = sess.authenticate()
        add("login", True, f"{u.get('FullName')} (id {u.get('Id')})")
    except EdvibeError as exc:
        add("login", False, str(exc))
    ok = all(c["ok"] for c in checks)

    def _fmt(d):
        lines = [f"[{'OK' if c['ok'] else 'FAIL'}] {c['check']}: {c['detail']}"
                 for c in d["checks"]]
        if not d["ok"]:
            lines.append("Fix: run `cli-anything-edvibe login` in your own terminal.")
        return "\n".join(lines)

    emit(ctx, {"ok": ok, "checks": checks}, human=_fmt)
    if not ok:
        raise SystemExit(1)


# -------------------------------------------------------------- materials
@cli.group("materials")
@click.pass_context
def materials(ctx):
    """Material (Book) operations."""


@materials.command("list")
@click.option("--take", default=100, show_default=True)
@click.pass_context
def materials_list(ctx, take):
    """List personal materials (folders & books)."""
    sess = get_session(ctx)
    items = sess.list_materials(take=take)
    rows = []
    for it in items:
        if "Folder" in it:
            f = it["Folder"]
            rows.append({"kind": "folder", "id": f.get("Id"), "name": f.get("Name"),
                         "count": f.get("CountMaterials")})
        else:
            b = it["Book"]
            rows.append({"kind": "book", "id": b.get("Id"), "name": b.get("Name"),
                         "school": b.get("IsSchoolBook"), "own": b.get("IsMySelfBook")})
    emit(ctx, {"total": len(rows), "items": rows},
         human=lambda d: "\n".join(
             f"[{r['kind']:6}] {r['id']:>9}  {r['name']}"
             + (f"  ({r['count']} materials)" if r["kind"] == "folder" else "")
             for r in d["items"]))


@materials.command("create")
@click.argument("name")
@click.option("--description", default="")
@click.option("--language", default=1, type=int, help="LanguageId (1 = English)")
@click.pass_context
def materials_create(ctx, name, description, language):
    """Create a new material (Book). Never deletes anything."""
    sess = get_session(ctx)
    book_id = sess.create_material(name, description=description, language_id=language)
    emit(ctx, {"material_id": book_id, "name": name},
         human=lambda d: f"Created material #{d['material_id']}: {d['name']}")


# ----------------------------------------------------------------- lesson
@cli.group("lesson")
@click.pass_context
def lesson(ctx):
    """Lesson (unit inside a material) operations."""


@lesson.command("add")
@click.option("--material", "material_id", required=True, type=int)
@click.option("--name", required=True)
@click.pass_context
def lesson_add(ctx, material_id, name):
    """Add a lesson (unit) to a material."""
    sess = get_session(ctx)
    course_id = sess.get_course_id(material_id)
    lesson_id, section_id = sess.create_lesson(material_id, course_id, name)
    emit(ctx, {"material_id": material_id, "course_id": course_id,
               "lesson_id": lesson_id, "section_id": section_id, "name": name},
         human=lambda d: f"Added lesson #{d['lesson_id']} '{d['name']}' "
                         f"(section #{d['section_id']}) to material #{d['material_id']}")


@lesson.command("show")
@click.option("--lesson", "lesson_id", required=True, type=int)
@click.pass_context
def lesson_show(ctx, lesson_id):
    """Show a lesson with its sections and exercises."""
    sess = get_session(ctx)
    les = sess.get_lesson(lesson_id)
    sections = list(les.get("Sections") or [])
    hw = les.get("HomeworkSection")
    if isinstance(hw, dict) and hw.get("Id"):
        sections.append(hw)
    out = {"lesson_id": lesson_id, "name": les.get("Name"), "number": les.get("Number"),
           "sections": []}
    for sec in sections:
        exercises = sess.load_exercises(sec.get("Id"), lesson_id)
        out["sections"].append({"section_id": sec.get("Id"), "name": sec.get("Name"),
                                "exercises": [{"id": e.get("Id"), "type": e.get("Type"),
                                               "name": (e.get("Name") or "")[:60]}
                                              for e in exercises]})
    emit(ctx, out, human=lambda d: _fmt_lesson(d))


@lesson.command("build")
@click.option("--file", "spec_file", required=True, type=click.Path(exists=True),
              help="Lesson spec JSON (see teacher-kit references/lesson-spec.md)")
@click.option("--lesson", "lesson_id", type=int, default=None,
              help="Append into an existing lesson id")
@click.option("--material", "material_id", type=int, default=None,
              help="Create a new lesson inside this material (Book) id")
@click.option("--name", default=None, help="Lesson name (for a new lesson)")
@click.option("--description", default=None, help="Lesson description")
@click.option("--dry-run", is_flag=True, help="Validate and show the plan only")
@click.pass_context
def lesson_build(ctx, spec_file, lesson_id, material_id, name, description, dry_run):
    """Build a full lesson (sections + exercises) from a JSON spec. Additive only:
    never edits or deletes anything that already exists."""
    from .core import lesson_spec
    with open(spec_file, "r", encoding="utf-8") as f:
        spec = json.load(f)
    if dry_run:
        try:
            res = lesson_spec.plan(spec)
        except ValueError as exc:
            raise click.ClickException(str(exc))
        emit(ctx, res, human=_fmt_plan)
        return
    if not lesson_id and not material_id:
        raise click.UsageError("pass --material (new lesson) or --lesson (existing)")
    sess = get_session(ctx)
    if name is None:
        name = spec.get("lesson_name")
    if description is None:
        description = spec.get("description")
    try:
        res = lesson_spec.build_lesson(sess, spec, material_id=material_id,
                                       lesson_id=lesson_id, name=name,
                                       description=description)
    except ValueError as exc:
        raise click.ClickException(str(exc))
    emit(ctx, res, human=_fmt_build)


def _fmt_plan(d):
    lines = [f"PLAN: {d.get('lesson_name') or '(existing lesson)'} — "
             f"{d['total_exercises']} exercises / {len(d['sections'])} sections"]
    for s in d["sections"]:
        lines.append(f"  {s['name']} ({len(s['exercises'])}):")
        for e in s["exercises"]:
            lines.append(f"    - {e['type']}: {(e['name'] or '')[:60]}")
    return "\n".join(lines)


def _fmt_build(d):
    total = sum(len(s["exercise_ids"]) for s in d["sections"])
    lines = [f"Lesson #{d['lesson_id']}" + (" (new)" if d["created"] else ""),
             f"Built {total} exercises in {len(d['sections'])} sections:"]
    for s in d["sections"]:
        lines.append(f"  '{s['name']}' #{s['section_id']} — "
                     f"{len(s['exercise_ids'])} exercises")
    if d.get("description_error"):
        lines.append(f"  description update failed: {d['description_error']}")
    return "\n".join(lines)


def _fmt_lesson(d):
    lines = [f"Lesson #{d['lesson_id']}: {d['name']}"]
    for sec in d["sections"]:
        lines.append(f"  Section #{sec['section_id']} '{sec['name']}' "
                     f"({len(sec['exercises'])} exercises)")
        for e in sec["exercises"]:
            lines.append(f"     - #{e['id']} type={e['type']} {e['name']}")
    return "\n".join(lines)


# ---------------------------------------------------------------- content
@cli.group("content")
@click.pass_context
def content(ctx):
    """Exercise/content operations."""


@content.command("add-note")
@click.option("--lesson", "lesson_id", required=True, type=int)
@click.option("--section", "section_id", required=True, type=int)
@click.option("--text", default=None, help="Raw HTML for the note")
@click.option("--file", "html_file", default=None, help="HTML file (whole content)")
@click.option("--name", default="", help="Optional exercise title")
@click.pass_context
def content_add_note(ctx, lesson_id, section_id, text, html_file, name):
    """Add a Note content block (Type 22) with HTML to a lesson section."""
    if text is None and html_file is None:
        raise click.UsageError("Provide --text or --file")
    if html_file:
        with open(html_file, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    sess = get_session(ctx)
    saved = sess.add_note(lesson_id, section_id, text, name=name)
    eid = saved.get("Id") if isinstance(saved, dict) else saved
    emit(ctx, {"exercise_id": eid, "lesson_id": lesson_id, "section_id": section_id},
         human=lambda d: f"Added note exercise #{d['exercise_id']}")


@content.command("show")
@click.option("--lesson", "lesson_id", required=True, type=int)
@click.option("--section", "section_id", required=True, type=int)
@click.pass_context
def content_show(ctx, lesson_id, section_id):
    """List exercises in a lesson section."""
    sess = get_session(ctx)
    items = sess.load_exercises(section_id, lesson_id)
    emit(ctx, {"exercises": items},
         human=lambda d: "\n".join(
             f"#{e.get('Id')} type={e.get('Type')} "
             f"name={(e.get('Name') or '')[:70]}" for e in d["exercises"]))


# --------------------------------------------------------------- import
@cli.command("import")
@click.option("--html", "html_file", required=True, type=click.Path(exists=True),
              help="Path to a hermes/esl-style HTML handout")
@click.option("--name", default=None, help="Material name (default: <title>)")
@click.option("--description", default="")
@click.option("--lesson", default="Lesson 1", help="Lesson name inside the material")
@click.pass_context
def import_html(ctx, html_file, name, description, lesson):
    """Import an HTML handout as a new Edvibe material with content notes."""
    sess = get_session(ctx)
    res = sess.import_html(html_file, material_name=name,
                           lesson_name=lesson, description=description)
    emit(ctx, res, human=lambda d: _fmt_import(d))


def _fmt_import(d):
    lines = [f"Material #{d['material_id']} (course #{d['course_id']})",
             f"Lesson #{d['lesson_id']} section #{d['section_id']}",
             f"Notes added: {len(d['notes'])}"]
    for n in d["notes"]:
        eid = n.get("Id") if isinstance(n, dict) else n
        lines.append(f"  - note exercise #{eid}")
    return "\n".join(lines)


# ------------------------------------------------------------------ REPL
@cli.command("repl", hidden=True)
@click.pass_context
def repl(ctx):
    """Interactive REPL (default when no subcommand is given)."""
    click.echo("cli-anything-edvibe REPL — type a command, 'help' or 'exit'.")
    while True:
        try:
            line = input("edvibe> ").strip()
        except (EOFError, KeyboardInterrupt):
            click.echo()
            break
        if not line:
            continue
        if line in ("exit", "quit"):
            break
        if line in ("help", "?"):
            click.echo("whoami | login | doctor | materials list | "
                       "materials create NAME | "
                       "lesson add --material ID --name N | "
                       "lesson build --file spec.json "
                       "[--material ID | --lesson ID] [--dry-run] | "
                       "lesson show --lesson ID | "
                       "content add-note --lesson ID --section ID --file F | "
                       "import --html FILE | logout | exit")
            continue
        try:
            args = shlex.split(line)
            cli.main(args=args, standalone_mode=False, obj=ctx.obj)
        except SystemExit:
            pass
        except (click.UsageError, EdvibeError, OSError) as exc:
            click.echo(f"error: {exc}", err=True)
        except Exception as exc:  # keep REPL alive
            click.echo(f"error: {type(exc).__name__}: {exc}", err=True)


def main():
    cli()


if __name__ == "__main__":
    sys.exit(main())
