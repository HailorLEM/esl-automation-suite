"""Utils package (namespace placeholder; repl skin kept minimal in CLI)."""
