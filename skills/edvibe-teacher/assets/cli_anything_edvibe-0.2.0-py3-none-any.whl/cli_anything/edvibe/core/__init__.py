"""Core: Edvibe WebSocket RPC client and API wrappers."""
